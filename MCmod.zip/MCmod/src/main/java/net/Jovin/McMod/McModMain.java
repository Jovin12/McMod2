package net.Jovin.McMod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class McModMain implements ModInitializer {

	public static final String Mod_ID = "mcmod"; 	//can only have Lower case, _, -, and numbers
	public static final Logger LOGGER = LoggerFactory.getLogger(Mod_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Hello Fabric world!");
	}
}
